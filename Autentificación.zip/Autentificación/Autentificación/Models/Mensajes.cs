﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Autentificación.Entidades
{
    public class Mensajes
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string NombreDifunto { get; set; }

        [Required]
        public string Mensaje { get; set; }

        [StringLength(100)]
        public string Departede { get; set; }

        [DataType(DataType.Date)]
        public DateTime FechaIngreso { get; set; }

        public string Estado { get; set; }
    }
}
