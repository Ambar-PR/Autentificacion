﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Autentificación.Data;
using Microsoft.AspNetCore.Authentication.JwtBearer;

namespace Autentificación
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            builder.Services.AddDbContext<AutentificaciónContext>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("AutentificaciónContext") ?? throw new InvalidOperationException("Connection string 'AutentificaciónContext' not found.")));

            // Add services to the container.
            builder.Services.AddRazorPages();

            // Configurar la autenticación JWT
            builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(options =>
                {
                    options.Authority = builder.Configuration["Authentication:JwtBearer:Authority"];
                    options.Audience = builder.Configuration["Authentication:JwtBearer:Audience"];
                });

            builder.Services.AddAuthorization(options =>
            {
                options.AddPolicy("ApiUser", policy => policy.RequireClaim("role", "api_access"));
            });

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            // Usar autenticación y autorización
            app.UseAuthentication();
            app.UseAuthorization();

            app.MapRazorPages();

            app.Run();
        }
    }
}




//using Microsoft.EntityFrameworkCore;
//using Microsoft.Extensions.DependencyInjection;
//using Autentificación.Data;
//using Microsoft.AspNetCore.Authentication.JwtBearer;

//namespace Autentificación
//{
//    public class Program
//    {
//        public static void Main(string[] args)
//        {
//            var builder = WebApplication.CreateBuilder(args);
//            builder.Services.AddDbContext<AutentificaciónContext>(options =>
//                options.UseSqlServer(builder.Configuration.GetConnectionString("AutentificaciónContext") ?? throw new InvalidOperationException("Connection string 'AutentificaciónContext' not found.")));

//            // Add services to the container.
//            builder.Services.AddRazorPages();

//            // Configurar la autenticación JWT
//            builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
//                .AddJwtBearer(options =>
//                {
//                    options.Authority = builder.Configuration["Authentication:JwtBearer:Authority"];
//                    options.Audience = builder.Configuration["Authentication:JwtBearer:Audience"];
//                });

//            builder.Services.AddAuthorization(options =>
//            {
//                options.AddPolicy("ApiUser", policy => policy.RequireClaim("role", "api_access"));
//            });

//            var app = builder.Build();

//            // Configure the HTTP request pipeline.
//            if (!app.Environment.IsDevelopment())
//            {
//                app.UseExceptionHandler("/Error");
//                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
//                app.UseHsts();
//            }

//            app.UseHttpsRedirection();
//            app.UseStaticFiles();

//            app.UseRouting();

//            // Usar autenticación y autorización
//            app.UseAuthentication();
//            app.UseAuthorization();

//            app.MapRazorPages();

//            app.Run();
//        }
//    }
//}