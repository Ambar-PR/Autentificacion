﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Autentificación.Data;
using Autentificación.Entidades;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Autentificación.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MensajesController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public MensajesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/Mensajes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Mensajes>>> GetMensajes()
        {
            return await _context.Mensajes.FromSqlRaw("EXEC spGetAllMensajes").ToListAsync();
        }

        // GET: api/Mensajes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Mensajes>> GetMensaje(int id)
        {
            var mensaje = await _context.Mensajes.FromSqlRaw("EXEC spGetMensajeById @Id={0}", id).FirstOrDefaultAsync();

            if (mensaje == null)
            {
                return NotFound();
            }

            return mensaje;
        }

        //// PUT: api/Mensajes/5
        //[HttpPut("{id}")]
        //public async Task<IActionResult> PutMensaje(int id, Mensajes mensaje)
        //{
        //    if (id != mensaje.Id)
        //    {
        //        return BadRequest();
        //    }

        //    var result = await _context.Database.ExecuteSqlRawAsync(
        //        "EXEC spUpdateMensaje @Id={0}, @NombreDifunto={1}, @MensajeTexto={2}, @DeParteDe={3}, @Estado={4}",
        //        mensaje.Id, mensaje.NombreDifunto, mensaje.Mensaje, mensaje.Departede, mensaje.Estado);

        //    if (result == 0)
        //    {
        //        return NotFound();
        //    }

        //    return NoContent();
        //}

        // PUT: api/Mensajes/5
        
        [HttpPut("{id}")]
        public async Task<IActionResult> PutMensaje(int id, Mensajes mensaje)
        {
            if (id != mensaje.Id)
            {
                return BadRequest();
            }

            var result = await _context.Database.ExecuteSqlRawAsync(
                "EXEC spUpdateMensaje @Id={0}, @NombreDifunto={1}, @MensajeTexto={2}, @DeParteDe={3}, @Estado={4}",
                mensaje.Id, mensaje.NombreDifunto, mensaje.Mensaje, mensaje.Departede, mensaje.Estado);

            if (result == 0)
            {
                return NotFound();
            }

            return NoContent();
        }


        // POST: api/Mensajes
        [HttpPost]
        public async Task<ActionResult<Mensajes>> PostMensaje(Mensajes mensaje)
        {
            await _context.Database.ExecuteSqlRawAsync(
                "EXEC spCreateMensaje @NombreDifunto={0}, @MensajeTexto={1}, @DeParteDe={2}, @Estado={3}",
                mensaje.NombreDifunto, mensaje.Mensaje, mensaje.Departede, mensaje.Estado);

            return CreatedAtAction("GetMensaje", new { id = mensaje.Id }, mensaje);
        }

        // DELETE: api/Mensajes/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteMensaje(int id)
        {
            var result = await _context.Database.ExecuteSqlRawAsync("EXEC spDeleteMensaje @Id={0}", id);

            if (result == 0)
            {
                return NotFound();
            }

            return NoContent();
        }
    }
}
