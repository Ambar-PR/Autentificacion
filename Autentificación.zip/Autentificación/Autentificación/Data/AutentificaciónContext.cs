﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Autentificación.Entidades;

namespace Autentificación.Data
{
    public class AutentificaciónContext : DbContext
    {
        public AutentificaciónContext (DbContextOptions<AutentificaciónContext> options)
            : base(options)
        {
        }

        public DbSet<Autentificación.Entidades.Mensajes> Mensajes { get; set; } = default!;
    }
}
