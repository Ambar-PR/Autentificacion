﻿using Microsoft.EntityFrameworkCore;
using Autentificación.Entidades;

namespace Autentificación.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Mensajes> Mensajes { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Map stored procedures
            modelBuilder.Entity<Mensajes>()
                .HasKey(e => e.Id);

            modelBuilder.Entity<Mensajes>()
                .Property(e => e.NombreDifunto)
                .HasColumnName("Nombre Difunto ");

            modelBuilder.Entity<Mensajes>()
                .Property(e => e.Mensaje)
                .HasColumnName("Mensaje ");

            modelBuilder.Entity<Mensajes>()
                .Property(e => e.Departede)
                .HasColumnName("De Parte de ");

            modelBuilder.Entity<Mensajes>()
                .Property(e => e.FechaIngreso)
                .HasColumnName("Fecha Ingreso ");

            modelBuilder.Entity<Mensajes>()
                .Property(e => e.Estado)
                .HasColumnName("Estado");
        }
    }
}
