﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Autentificación.Data;
using Autentificación.Entidades;

namespace Autentificación.Pages.Mensaje
{
    public class DeleteModel : PageModel
    {
        private readonly Autentificación.Data.AutentificaciónContext _context;

        public DeleteModel(Autentificación.Data.AutentificaciónContext context)
        {
            _context = context;
        }

        [BindProperty]
      public Mensajes Mensajes { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Mensajes == null)
            {
                return NotFound();
            }

            var mensajes = await _context.Mensajes.FirstOrDefaultAsync(m => m.Id == id);

            if (mensajes == null)
            {
                return NotFound();
            }
            else 
            {
                Mensajes = mensajes;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null || _context.Mensajes == null)
            {
                return NotFound();
            }
            var mensajes = await _context.Mensajes.FindAsync(id);

            if (mensajes != null)
            {
                Mensajes = mensajes;
                _context.Mensajes.Remove(Mensajes);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
