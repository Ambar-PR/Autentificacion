﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Autentificación.Data;
using Autentificación.Entidades;

namespace Autentificación.Pages.Mensaje
{
    public class IndexModel : PageModel
    {
        private readonly Autentificación.Data.AutentificaciónContext _context;

        public IndexModel(Autentificación.Data.AutentificaciónContext context)
        {
            _context = context;
        }

        public IList<Mensajes> Mensajes { get;set; } = default!;

        public async Task OnGetAsync()
        {
            if (_context.Mensajes != null)
            {
                Mensajes = await _context.Mensajes.ToListAsync();
            }
        }
    }
}
